# Ultimate Client

A lightweight Fabric HUD client for Minecraft 1.21.11 (original code, Lunar-style HUD mods).

## Modules
FPS, CPS, Ping, Coordinates, Direction, Clock, Memory, Keystrokes (WASD, mouse, space), Armor Status, Potion Status.

## Use
- **Right Shift** opens the HUD editor (rebind in Controls -> Ultimate Client).
- Drag to move, scroll over a module to resize, right-click (or the left list) to toggle, middle-click toggles its background.
- **ESC** saves to `config/ultimateclient.json`.

## Build
Requires JDK 21 and Gradle (or generate the wrapper once with `gradle wrapper`).

    gradle build          # jar ends up in build/libs/ultimate-client-1.0.0.jar
    gradle runClient      # test in a dev client

Drop the jar plus Fabric Loader 0.18.4+ and Fabric API 0.141.1+1.21.11 into your mods folder.
