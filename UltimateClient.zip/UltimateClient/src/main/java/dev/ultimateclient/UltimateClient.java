package dev.ultimateclient;

import dev.ultimateclient.config.ConfigManager;
import dev.ultimateclient.gui.HudEditorScreen;
import dev.ultimateclient.hud.ModuleManager;
import dev.ultimateclient.util.ClickTracker;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class UltimateClient implements ClientModInitializer {
    public static final String NAME = "Ultimate Client";

    private static KeyBinding editorKey;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ConfigManager.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("ultimateclient", "main"));
        editorKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ultimateclient.editor",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (editorKey.wasPressed()) {
                mc.setScreen(new HudEditorScreen());
            }
        });

        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.of("ultimateclient", "hud"),
                (ctx, tickCounter) -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    ClickTracker.poll(mc);
                    if (mc.options.hudHidden || mc.currentScreen instanceof HudEditorScreen) return;
                    ModuleManager.renderAll(ctx, mc);
                });
    }
}
