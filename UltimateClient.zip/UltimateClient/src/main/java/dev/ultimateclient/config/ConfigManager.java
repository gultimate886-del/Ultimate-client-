package dev.ultimateclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import dev.ultimateclient.hud.HudModule;
import dev.ultimateclient.hud.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Saves module positions/scale/enabled state to config/ultimateclient.json. */
public final class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("ultimateclient.json");

    private ConfigManager() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        try {
            JsonObject root = GSON.fromJson(Files.readString(FILE), JsonObject.class);
            if (root == null) return;
            for (HudModule m : ModuleManager.MODULES) {
                if (!root.has(m.id)) continue;
                JsonObject o = root.getAsJsonObject(m.id);
                if (o.has("enabled")) m.enabled = o.get("enabled").getAsBoolean();
                if (o.has("x")) m.x = o.get("x").getAsInt();
                if (o.has("y")) m.y = o.get("y").getAsInt();
                if (o.has("scale")) m.scale = o.get("scale").getAsFloat();
                if (o.has("background")) m.background = o.get("background").getAsBoolean();
            }
        } catch (Exception e) {
            System.err.println("[UltimateClient] Failed to load config: " + e);
        }
    }

    public static void save() {
        JsonObject root = new JsonObject();
        for (HudModule m : ModuleManager.MODULES) {
            JsonObject o = new JsonObject();
            o.addProperty("enabled", m.enabled);
            o.addProperty("x", m.x);
            o.addProperty("y", m.y);
            o.addProperty("scale", m.scale);
            o.addProperty("background", m.background);
            root.add(m.id, o);
        }
        try {
            Files.writeString(FILE, GSON.toJson(root));
        } catch (IOException e) {
            System.err.println("[UltimateClient] Failed to save config: " + e);
        }
    }
}
