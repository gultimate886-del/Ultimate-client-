package dev.ultimateclient.gui;

import dev.ultimateclient.config.ConfigManager;
import dev.ultimateclient.hud.HudModule;
import dev.ultimateclient.hud.ModuleManager;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

/**
 * Drag modules to move them, scroll over one to resize it, right-click to toggle,
 * or use the list on the left. Press ESC to save and close.
 */
public class HudEditorScreen extends Screen {
    private static final int PANEL_X = 6;
    private static final int PANEL_Y = 30;
    private static final int PANEL_W = 110;
    private static final int ROW_H = 13;

    private HudModule dragging;
    private double offX;
    private double offY;

    public HudEditorScreen() {
        super(Text.literal("Ultimate Client"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        List<HudModule> modules = ModuleManager.MODULES;

        for (HudModule m : modules) {
            m.render(ctx, client, true);
            int color = m.enabled ? 0xFF55FF55 : 0xFF888888;
            if (!m.enabled) ctx.fill(m.x, m.y, m.x + m.width(), m.y + m.height(), 0x90000000);
            if (m == dragging || m.contains(mouseX, mouseY)) color = 0xFFFFFFFF;
            ctx.drawBorder(m.x - 1, m.y - 1, m.width() + 2, m.height() + 2, color);
        }

        // Side panel
        int panelH = 16 + modules.size() * ROW_H + 4;
        ctx.fill(PANEL_X, PANEL_Y, PANEL_X + PANEL_W, PANEL_Y + panelH, 0xC0101010);
        ctx.drawText(textRenderer, "Ultimate Client", PANEL_X + 4, PANEL_Y + 4, 0xFFFFD700, true);
        for (int i = 0; i < modules.size(); i++) {
            HudModule m = modules.get(i);
            int ry = PANEL_Y + 16 + i * ROW_H;
            boolean hover = mouseX >= PANEL_X && mouseX <= PANEL_X + PANEL_W && mouseY >= ry && mouseY < ry + ROW_H;
            if (hover) ctx.fill(PANEL_X + 1, ry, PANEL_X + PANEL_W - 1, ry + ROW_H, 0x40FFFFFF);
            ctx.drawText(textRenderer, m.name, PANEL_X + 4, ry + 3, 0xFFFFFFFF, false);
            String state = m.enabled ? "ON" : "OFF";
            ctx.drawText(textRenderer, state, PANEL_X + PANEL_W - 4 - textRenderer.getWidth(state), ry + 3,
                    m.enabled ? 0xFF55FF55 : 0xFFFF5555, false);
        }

        String hint = "Drag: move   Scroll: resize   Right-click: toggle   ESC: save & close";
        ctx.drawText(textRenderer, hint, (width - textRenderer.getWidth(hint)) / 2, 10, 0xFFFFFFFF, true);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x();
        double my = click.y();
        int button = click.button();
        List<HudModule> modules = ModuleManager.MODULES;

        if (button == 0 && mx >= PANEL_X && mx <= PANEL_X + PANEL_W) {
            for (int i = 0; i < modules.size(); i++) {
                int ry = PANEL_Y + 16 + i * ROW_H;
                if (my >= ry && my < ry + ROW_H) {
                    modules.get(i).enabled = !modules.get(i).enabled;
                    return true;
                }
            }
        }

        for (int i = modules.size() - 1; i >= 0; i--) {
            HudModule m = modules.get(i);
            if (!m.contains(mx, my)) continue;
            if (button == 0) {
                dragging = m;
                offX = mx - m.x;
                offY = my - m.y;
            } else if (button == 1) {
                m.enabled = !m.enabled;
            } else if (button == 2) {
                m.background = !m.background;
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragging != null && click.button() == 0) {
            dragging.x = (int) Math.max(0, Math.min(width - dragging.width(), click.x() - offX));
            dragging.y = (int) Math.max(0, Math.min(height - dragging.height(), click.y() - offY));
            return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (click.button() == 0) dragging = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontal, double vertical) {
        List<HudModule> modules = ModuleManager.MODULES;
        for (int i = modules.size() - 1; i >= 0; i--) {
            HudModule m = modules.get(i);
            if (m.contains(mx, my)) {
                m.scale = Math.max(0.5f, Math.min(3.0f, m.scale + (float) vertical * 0.1f));
                return true;
            }
        }
        return super.mouseScrolled(mx, my, horizontal, vertical);
    }

    @Override
    public void removed() {
        ConfigManager.save();
    }
}
