package dev.ultimateclient.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Base class for every movable HUD element. */
public abstract class HudModule {
    public final String id;
    public final String name;
    public boolean enabled;
    public int x;
    public int y;
    public float scale = 1.0f;
    public boolean background = true;

    /** Unscaled size, updated by draw(). */
    protected int w = 40;
    protected int h = 14;

    protected HudModule(String id, String name, int x, int y, boolean enabled) {
        this.id = id;
        this.name = name;
        this.x = x;
        this.y = y;
        this.enabled = enabled;
    }

    /** Draw at origin (0,0). Must set w and h. preview = true when shown inside the editor. */
    protected abstract void draw(DrawContext ctx, MinecraftClient mc, boolean preview);

    public final void render(DrawContext ctx, MinecraftClient mc, boolean preview) {
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate((float) x, (float) y);
        m.scale(scale, scale);
        draw(ctx, mc, preview);
        m.popMatrix();
    }

    public int width() { return Math.round(w * scale); }
    public int height() { return Math.round(h * scale); }

    public boolean contains(double mx, double my) {
        return mx >= x && mx <= x + width() && my >= y && my <= y + height();
    }

    protected void box(DrawContext ctx, int bw, int bh) {
        if (background) ctx.fill(0, 0, bw, bh, 0x90000000);
    }
}
