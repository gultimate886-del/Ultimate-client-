package dev.ultimateclient.hud;

import dev.ultimateclient.modules.ArmorModule;
import dev.ultimateclient.modules.KeystrokesModule;
import dev.ultimateclient.modules.PotionModule;
import dev.ultimateclient.modules.TextModule;
import dev.ultimateclient.util.ClickTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.gui.DrawContext;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ModuleManager {
    public static final List<HudModule> MODULES = new ArrayList<>();
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm:ss");

    private ModuleManager() {}

    public static void init() {
        MODULES.clear();
        MODULES.add(new TextModule("fps", "FPS", 4, 4, true, mc -> mc.getCurrentFps() + " FPS"));
        MODULES.add(new TextModule("cps", "CPS", 4, 22, true,
                mc -> ClickTracker.left() + " | " + ClickTracker.right() + " CPS"));
        MODULES.add(new TextModule("ping", "Ping", 4, 40, true, mc -> ping(mc) + " ms"));
        MODULES.add(new TextModule("coords", "Coordinates", 4, 58, true, mc -> {
            if (mc.player == null) return "XYZ: 0.0 / 64.0 / 0.0";
            return String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ());
        }));
        MODULES.add(new TextModule("direction", "Direction", 4, 76, false, mc -> {
            if (mc.player == null) return "North (0°)";
            String dir = mc.player.getHorizontalFacing().asString();
            dir = Character.toUpperCase(dir.charAt(0)) + dir.substring(1);
            float yaw = net.minecraft.util.math.MathHelper.wrapDegrees(mc.player.getYaw());
            return String.format(Locale.ROOT, "%s (%.0f°)", dir, yaw);
        }));
        MODULES.add(new TextModule("clock", "Clock", 4, 94, false, mc -> LocalTime.now().format(CLOCK)));
        MODULES.add(new TextModule("memory", "Memory", 4, 112, false, mc -> {
            Runtime r = Runtime.getRuntime();
            long used = (r.totalMemory() - r.freeMemory()) / 1048576L;
            return "Mem: " + used + " / " + (r.maxMemory() / 1048576L) + " MB";
        }));
        MODULES.add(new KeystrokesModule(4, 140, true));
        MODULES.add(new ArmorModule(90, 140, true));
        MODULES.add(new PotionModule(160, 4, true));
    }

    public static void renderAll(DrawContext ctx, MinecraftClient mc) {
        for (HudModule m : MODULES) {
            if (m.enabled) m.render(ctx, mc, false);
        }
    }

    private static int ping(MinecraftClient mc) {
        ClientPlayNetworkHandler nh = mc.getNetworkHandler();
        if (nh == null || mc.player == null) return 0;
        PlayerListEntry e = nh.getPlayerListEntry(mc.player.getUuid());
        return e == null ? 0 : e.getLatency();
    }
}
