package dev.ultimateclient.modules;

import dev.ultimateclient.hud.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class ArmorModule extends HudModule {
    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    public ArmorModule(int x, int y, boolean enabled) {
        super("armor", "Armor Status", x, y, enabled);
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, boolean preview) {
        TextRenderer tr = mc.textRenderer;
        w = 52;
        h = 4 * 18 + 2;
        box(ctx, w, h);
        for (int i = 0; i < 4; i++) {
            ItemStack stack = mc.player == null ? ItemStack.EMPTY : mc.player.getEquippedStack(SLOTS[i]);
            if (stack.isEmpty() && preview) stack = sample(i);
            if (stack.isEmpty()) continue;
            int y = 1 + i * 18;
            ctx.drawItem(stack, 2, y);
            if (stack.isDamageable()) {
                int left = stack.getMaxDamage() - stack.getDamage();
                ctx.drawText(tr, String.valueOf(left), 22, y + 4, 0xFFFFFFFF, true);
            }
        }
    }

    private static ItemStack sample(int i) {
        return new ItemStack(switch (i) {
            case 0 -> Items.DIAMOND_HELMET;
            case 1 -> Items.DIAMOND_CHESTPLATE;
            case 2 -> Items.DIAMOND_LEGGINGS;
            default -> Items.DIAMOND_BOOTS;
        });
    }
}
