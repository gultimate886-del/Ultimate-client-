package dev.ultimateclient.modules;

import dev.ultimateclient.hud.HudModule;
import dev.ultimateclient.util.ClickTracker;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.GameOptions;

public class KeystrokesModule extends HudModule {
    public KeystrokesModule(int x, int y, boolean enabled) {
        super("keystrokes", "Keystrokes", x, y, enabled);
        w = 64;
        h = 78;
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, boolean preview) {
        TextRenderer tr = mc.textRenderer;
        GameOptions o = mc.options;
        w = 64;
        h = 78;
        key(ctx, tr, 22, 0, 20, 20, "W", null, o.forwardKey.isPressed());
        key(ctx, tr, 0, 22, 20, 20, "A", null, o.leftKey.isPressed());
        key(ctx, tr, 22, 22, 20, 20, "S", null, o.backKey.isPressed());
        key(ctx, tr, 44, 22, 20, 20, "D", null, o.rightKey.isPressed());
        key(ctx, tr, 0, 44, 31, 20, "LMB", ClickTracker.left() + " CPS", ClickTracker.leftDown());
        key(ctx, tr, 33, 44, 31, 20, "RMB", ClickTracker.right() + " CPS", ClickTracker.rightDown());
        key(ctx, tr, 0, 66, 64, 12, "SPACE", null, o.jumpKey.isPressed());
    }

    private void key(DrawContext ctx, TextRenderer tr, int x, int y, int bw, int bh,
                     String label, String sub, boolean down) {
        ctx.fill(x, y, x + bw, y + bh, down ? 0xB0FFFFFF : 0x90000000);
        int color = down ? 0xFF000000 : 0xFFFFFFFF;
        if (sub == null) {
            ctx.drawText(tr, label, x + (bw - tr.getWidth(label)) / 2, y + (bh - 8) / 2 + 1, color, false);
        } else {
            ctx.drawText(tr, label, x + (bw - tr.getWidth(label)) / 2, y + 2, color, false);
            ctx.drawText(tr, sub, x + (bw - tr.getWidth(sub)) / 2, y + 11, color, false);
        }
    }
}
