package dev.ultimateclient.modules;

import dev.ultimateclient.hud.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;

import java.util.ArrayList;
import java.util.List;

public class PotionModule extends HudModule {
    public PotionModule(int x, int y, boolean enabled) {
        super("potions", "Potion Status", x, y, enabled);
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, boolean preview) {
        TextRenderer tr = mc.textRenderer;
        List<String> lines = new ArrayList<>();
        if (mc.player != null) {
            for (StatusEffectInstance e : mc.player.getStatusEffects()) {
                String name = e.getEffectType().value().getName().getString();
                if (e.getAmplifier() > 0) name += " " + (e.getAmplifier() + 1);
                lines.add(name + "  " + time(e));
            }
        }
        if (lines.isEmpty() && preview) {
            lines.add("Speed 2  0:30");
            lines.add("Strength  1:45");
        }
        int max = 40;
        for (String s : lines) max = Math.max(max, tr.getWidth(s));
        w = max + 8;
        h = Math.max(1, lines.size()) * 11 + 4;
        if (lines.isEmpty()) {
            w = 1;
            h = 1;
            return;
        }
        box(ctx, w, h);
        for (int i = 0; i < lines.size(); i++) {
            ctx.drawText(tr, lines.get(i), 4, 3 + i * 11, 0xFFFFFFFF, true);
        }
    }

    private static String time(StatusEffectInstance e) {
        if (e.isInfinite()) return "**:**";
        int sec = e.getDuration() / 20;
        return (sec / 60) + ":" + String.format("%02d", sec % 60);
    }
}
