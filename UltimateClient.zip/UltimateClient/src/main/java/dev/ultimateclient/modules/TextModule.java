package dev.ultimateclient.modules;

import dev.ultimateclient.hud.HudModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.function.Function;

/** A single line of text driven by a supplier (FPS, CPS, ping, coords, ...). */
public class TextModule extends HudModule {
    private final Function<MinecraftClient, String> text;

    public TextModule(String id, String name, int x, int y, boolean enabled, Function<MinecraftClient, String> text) {
        super(id, name, x, y, enabled);
        this.text = text;
    }

    @Override
    protected void draw(DrawContext ctx, MinecraftClient mc, boolean preview) {
        TextRenderer tr = mc.textRenderer;
        String s = text.apply(mc);
        if (s == null) s = "";
        w = tr.getWidth(s) + 8;
        h = 14;
        box(ctx, w, h);
        ctx.drawText(tr, s, 4, 3, 0xFFFFFFFF, true);
    }
}
