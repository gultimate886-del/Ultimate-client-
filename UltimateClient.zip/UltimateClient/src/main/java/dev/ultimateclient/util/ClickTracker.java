package dev.ultimateclient.util;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;

/** Polls the mouse every frame and counts clicks in the last second (no mixins needed). */
public final class ClickTracker {
    private static final ArrayDeque<Long> LEFT = new ArrayDeque<>();
    private static final ArrayDeque<Long> RIGHT = new ArrayDeque<>();
    private static boolean lastLeft;
    private static boolean lastRight;
    private static boolean leftDown;
    private static boolean rightDown;

    private ClickTracker() {}

    public static void poll(MinecraftClient mc) {
        long handle = mc.getWindow().getHandle();
        boolean inGame = mc.currentScreen == null;
        leftDown = inGame && GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        rightDown = inGame && GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        long now = System.currentTimeMillis();
        if (leftDown && !lastLeft) LEFT.addLast(now);
        if (rightDown && !lastRight) RIGHT.addLast(now);
        lastLeft = leftDown;
        lastRight = rightDown;
        prune(LEFT, now);
        prune(RIGHT, now);
    }

    private static void prune(ArrayDeque<Long> q, long now) {
        while (!q.isEmpty() && now - q.peekFirst() > 1000) q.removeFirst();
    }

    public static int left() { return LEFT.size(); }
    public static int right() { return RIGHT.size(); }
    public static boolean leftDown() { return leftDown; }
    public static boolean rightDown() { return rightDown; }
}
